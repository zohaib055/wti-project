<?php $__env->startSection("content"); ?>

<div class="row">
	<div class="col-md-12">
		
		<div class="panel panel-primary" data-collapsed="0">
		
			<div class="panel-heading">
				<div class="panel-title">
				 <h3>Update Plot</h3>
				</div>
				
			</div>
			
			<div class="panel-body">

			<form role="form" class="form-horizontal form-groups-bordered">
				
				
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Plot</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="plot" value="<?php echo e($plot->plot); ?>" disabled="disabled">
						</div>
					</div>

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Size</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="size" value="<?php echo e($plot->size); ?>" disabled="disabled">
						</div>
					</div>

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Number</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="number" value="<?php echo e($plot->number); ?>" disabled="disabled">
						</div>
					</div>
					
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Reg</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="reg" value="<?php echo e($plot->reg); ?>" disabled="disabled">
						</div>
					</div>
					
					
					
					<div class="form-group">
						<label for="field-ta" class="col-sm-3 control-label">Address</label>
						
						<div class="col-sm-5">
							<textarea class="form-control"  name="address" disabled="disabled"><?php echo e($plot->address); ?></textarea>
						</div>
					</div>

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Contact No</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="contact_no" value="<?php echo e($plot->contact_no); ?>" disabled="disabled">
						</div>
					</div>



					<div class="form-group">
						<label for="field-ta" class="col-sm-3 control-label">Remarks</label>
						
						<div class="col-sm-5">
							<textarea class="form-control"  name="remarks" disabled="disabled"><?php echo e($plot->remarks); ?></textarea>
						</div>
					</div>

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Status</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="status" value="<?php echo e($plot->status); ?>" disabled="disabled">
						</div>
					</div>

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Dues</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="dues" value="<?php echo e($plot->dues); ?>" disabled="disabled">
						</div>
					</div>


					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Names</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="names" value="<?php echo e($plot->names); ?>" disabled="disabled">
						</div>
					</div>


					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Block</label>
						
						<div class="col-sm-5">
							<input type="text" class="form-control" name="block" value="<?php echo e($plot->block); ?>" disabled="disabled">
						</div>
					</div>

                 </form>
		
			</div>
		
		</div>
	
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>