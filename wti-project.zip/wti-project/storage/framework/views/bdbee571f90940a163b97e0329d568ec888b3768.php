<div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
    <strong><?php echo e($title); ?></strong>&nbsp;<?php echo e($slot); ?>

</div>