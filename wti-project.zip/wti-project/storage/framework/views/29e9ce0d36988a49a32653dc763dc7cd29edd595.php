<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<?php echo $__env->make("layouts.head", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(Auth::check()): ?>
<body class="page-body  page-fade" data-url="">

<?php else: ?>

<body class="page-body login-page login-form-fall" data-url="">

<?php endif; ?>

 <?php if(Auth::check()): ?>

<div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always --> 

  <?php $__env->startSection("sidebar"); ?>
    
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

  <?php echo $__env->yieldSection(); ?>

 <?php endif; ?>

<?php if(Auth::check()): ?>  
<div class="main-content">

<?php endif; ?>

<?php if(Auth::check()): ?>        
<div class="row">
    
   <?php echo $__env->make("layouts.widgets.profile1", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
   <?php echo $__env->make("layouts.widgets.profile2", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<hr />

<?php endif; ?>

<?php if(Session::has('msg')): ?>

<?php $__env->startComponent('inc.alert'); ?>
    
    <?php $__env->slot('type'); ?>

     <?php echo e(Session::get('type')); ?>

        
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('title'); ?>

        Message : 
        
    <?php $__env->endSlot(); ?>

     <?php echo e(Session::get('msg')); ?>


<?php echo $__env->renderComponent(); ?>

<?php endif; ?>


<?php $__env->startSection("content"); ?>

 <h3>Not Available</h3>

<?php echo $__env->yieldSection(); ?>

<!-- Footer -->

<?php if(Auth::check()): ?>  

<?php echo $__env->make("layouts.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
<?php endif; ?>
    <?php echo $__env->make("layouts.scripts", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>