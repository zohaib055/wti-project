<?php $__env->startSection("content"); ?>

<h3>All Plots</h3>


<table class="table table-bordered datatable" id="table-1">
	<thead>
		<tr>
			<th data-hide="phone">Plot</th>
			<th>Size</th>
			<th data-hide="phone">Contact No</th>
			<th data-hide="phone,tablet">Address</th>
			<th>Block</th>
			<th>Actions</th>
		</tr>
	</thead>
	<tbody>
	<?php $__empty_1 = true; $__currentLoopData = $plots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<tr class="gradeU">
			<td><?php echo e($plot->plot); ?></td>
			<td><?php echo e($plot->size); ?></td>
			<td><?php echo e($plot->contact_no); ?></t<?php echo e($plot->plot); ?>d>
			<td class="center"><?php echo e($plot->address); ?></td>
			<td class="center"><?php echo e($plot->block); ?></td>
			<td>
				
              <a href="<?php echo e(route('plots.edit', ['id' => $plot->id])); ?>" class="btn btn-default btn-sm btn-icon icon-left">
					<i class="entypo-pencil"></i>
					Edit
			  </a>

			  <a href="javascript:delete_plot(<?php echo e($plot->id); ?>);" class="btn btn-danger btn-sm btn-icon icon-left">
					<i class="entypo-cancel"></i>
					Delete
			  </a>

			  <a href="<?php echo e(route('plots.show', ['id' => $plot->id])); ?>" class="btn btn-success btn-sm btn-icon icon-left">
					<i class="entypo-eye"></i>
					View
			 </a>


			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

   

	<?php endif; ?>
	</tbody>
	
</table>
<?php echo e(csrf_field()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>