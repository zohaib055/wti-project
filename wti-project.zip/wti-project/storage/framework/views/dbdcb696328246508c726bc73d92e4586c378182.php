<footer class="main">
    
        
    <!-- &copy; 2014 <strong>Neon</strong> Admin Theme by <a href="http://laborator.co" target="_blank">Laborator</a> -->



    <script type="text/javascript">
		jQuery(document).ready(function($) 
		{
		    // Sample Toastr Notification
		    setTimeout(function()
		    {           
		        var opts = {
		            "closeButton": true,
		            "debug": false,
		            "positionClass": rtl() || public_vars.$pageContainer.hasClass('right-sidebar') ? "toast-top-left" : "toast-top-right",
		            "toastClass": "black",
		            "onclick": null,
		            "showDuration": "300",
		            "hideDuration": "1000",
		            "timeOut": "5000",
		            "extendedTimeOut": "1000",
		            "showEasing": "swing",
		            "hideEasing": "linear",
		            "showMethod": "fadeIn",
		            "hideMethod": "fadeOut"
		        };

		       // toastr.success("You have been awarded with 1 year free subscription. Enjoy it!", "Account Subcription Updated", opts);
		    }, 3000);
    
        
		});


		</script>
    
</footer>   
