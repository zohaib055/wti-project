<div class="alert alert-{{$type}} fade in alert-dismissable" style="margin-top:18px;">
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
    <strong>{{$title}}</strong>&nbsp;{{$slot}}
</div>